// import CounterContainer from "./container/CounterContainer";
import PostListContainer from "./container/PostListContainer";

function App() {
  return (
    // <CounterContainer />    
    <PostListContainer />
  );
}

export default App;
